#pragma once

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

bool app_init();
