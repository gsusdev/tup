#include "app_main.h"

#include <string.h>

#include "app_settings.h"
#include "app_hal.h"
#include "app_link.h"
#include "app_protocol.h"

static struct
{
	bool isInit;
	uint32_t currentTimestamp_ms;
	app_protocol_masterOutputData_t masterOutput;
	app_protocol_slaveOutputData_t slaveOutput;
} app = {0};

static bool initButton();
static void handleButton();

static bool initLink();
static void handleLink();

static void setTime();
static void getTime();

bool app_init()
{
	if (!initLink())
	{
		return false;
	}

	memset(&app.masterOutput, 0, sizeof(app.masterOutput));




	app.isInit = true;

	return true;
}
